export const environment = {
  production: false,
  path: "https://api.spacexdata.com/v3"
};
