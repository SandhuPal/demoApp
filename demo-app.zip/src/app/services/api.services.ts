import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from "./../../environments/environment";


@Injectable()
export class ApiService {

  path = environment.path;
  constructor(private http: HttpClient) {}


    getAll() {
        return this.http.get<any>(this.path + `/launches`);
    }

    getOneLaunchDetails(id:any) {
      return this.http.get<any>(this.path + `/launches/`+id);
    }
     
}

