import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-top-bar',
  templateUrl: './app-top-bar.component.html',
  styleUrls: ['./app-top-bar.component.scss']
})
export class AppTopBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
