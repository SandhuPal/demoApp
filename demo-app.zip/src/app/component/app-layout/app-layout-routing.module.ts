import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppLayoutComponent } from './app-layout.component';
import { LaunchMissionComponent } from './../launch-mission/launch-mission.component';
import { LaunchMissionDetailsComponent } from './../launch-mission-details/launch-mission-details.component';

const routes: Routes = [  {
      path: '',
      component: AppLayoutComponent,
      children: [
        {
          path: '',
          component: LaunchMissionComponent,
          loadChildren: () => import('./../launch-mission/launch-mission.module').then(m => m.LaunchMissionModule)
        },
        {
          path: 'launch-details/:flight_number',
          component: LaunchMissionDetailsComponent,
          loadChildren: () => import('./../launch-mission-details/launch-mission-details.module').then(m => m.LaunchMissionDetailsModule)
        }
      ]} 
  ];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppLayoutRoutingModule { }
