import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppLayoutComponent } from './app-layout.component';
import { AppLayoutRoutingModule } from './app-layout-routing.module';
import { AppNavigationComponent } from './app-navigation/app-navigation.component';
import { AppTopBarComponent } from './app-top-bar/app-top-bar.component';

@NgModule({
  declarations: [AppLayoutComponent, AppNavigationComponent, AppTopBarComponent],
  imports: [
    CommonModule,
    AppLayoutRoutingModule
  ]
})
export class AppLayoutModule { }
