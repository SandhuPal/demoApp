import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LaunchMissionComponent } from './../launch-mission/launch-mission.component';

@NgModule({
  declarations: [LaunchMissionComponent],
  imports: [
    CommonModule
  ]
})
export class LaunchMissionModule { }
