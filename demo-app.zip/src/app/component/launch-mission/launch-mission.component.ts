import { Component, OnInit } from '@angular/core';
import { ApiService } from './../../services/api.services';
import { Observable } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-launch-mission',
  templateUrl: './launch-mission.component.html',
  styleUrls: ['./launch-mission.component.scss']
})
export class LaunchMissionComponent implements OnInit {

  private launchesList?: Observable<any>;
  launchesData: any;

  constructor(private  apiService:  ApiService,
    private router: Router) { }

  ngOnInit(): void {
    this.launchesList = this.apiService.getAll();
    this.launchesList.subscribe((res:any) => { 
      this.launchesData = res;
    })
  }

  routerLink(id:any){
    this.router.navigate(["/launch-details/"+id]);
  }
}
