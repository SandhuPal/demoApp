import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LaunchMissionDetailsComponent } from './launch-mission-details.component';

describe('LaunchMissionDetailsComponent', () => {
  let component: LaunchMissionDetailsComponent;
  let fixture: ComponentFixture<LaunchMissionDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LaunchMissionDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LaunchMissionDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
