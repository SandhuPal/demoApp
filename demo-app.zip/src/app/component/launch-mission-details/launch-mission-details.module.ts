import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LaunchMissionDetailsComponent } from './../launch-mission-details/launch-mission-details.component';

@NgModule({
  declarations: [LaunchMissionDetailsComponent],
  imports: [
    CommonModule
  ]
})
export class LaunchMissionDetailsModule { }
