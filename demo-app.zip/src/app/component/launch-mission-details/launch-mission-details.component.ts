import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiService } from './../../services/api.services';

@Component({
  selector: 'app-launch-mission-details',
  templateUrl: './launch-mission-details.component.html',
  styleUrls: ['./launch-mission-details.component.scss']
})
export class LaunchMissionDetailsComponent implements OnInit {

  private launchesListDetails?: Observable<any>;
  launchesDetails: any;

  constructor(private  apiService:  ApiService,
    private  route:  ActivatedRoute) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {

    
      this.launchesListDetails = this.apiService.getOneLaunchDetails(params['flight_number']);
      this.launchesListDetails.subscribe((res:any) => { 
        this.launchesDetails = res;
        console.log(res)
      });
    });

  }

}
